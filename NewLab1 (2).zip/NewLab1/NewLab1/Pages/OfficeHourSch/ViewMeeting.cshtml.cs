using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace NewLab1.Pages.OfficeHourSch
{
    public class ViewMeetingModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
