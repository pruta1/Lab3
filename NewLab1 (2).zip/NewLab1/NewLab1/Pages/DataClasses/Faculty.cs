﻿namespace NewLab1.Pages.DataClasses
{
    public class Faculty
    {
        public int FacultyID { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string Username { get; set; }

        public string FacultyEmail { get; set; }

    }
}