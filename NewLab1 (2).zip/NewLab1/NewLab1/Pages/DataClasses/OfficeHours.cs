﻿namespace NewLab1.Pages.DataClasses
{
    public class OfficeHours
    {
        public int OfficeHourID { get; set; }

        public int OfficeNumber { get; set; }
        public string Date { get; set; }

        public string Time { get; set; }

        public int FacultyID { get; set; }

        public string StudentName { get; set;}


    }
}
