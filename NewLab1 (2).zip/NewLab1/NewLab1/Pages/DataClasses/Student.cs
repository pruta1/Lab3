﻿namespace NewLab1.Pages.DataClasses
{
    public class Student
    {
        public int StudentID { get; set; }

        public string FirstName { get; set; }
        public string LastName { get; set; }

        public string StuEmail { get; set; }

        public int Phone { get; set; }
    }
}
