﻿namespace NewLab1.Pages.DataClasses
{
    public class Meeting
    {
        public int MeetingID { get; set; }

        public int OfficeNumber { get; set; }
        public string Date { get; set; }

        public string Time { get; set; }

        public int FacultyID { get; set; }

        public int StudentID { get; set; }

    }
}
